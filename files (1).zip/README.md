# Gravity — Synthetic Wealth Data Generator

A single, seeded, tunable script that produces a **labeled** book of wealth-management
clients for the *Gravity* held-away / share-of-wallet concept — data you can both
**demo** and **score KPIs against**, because you own the ground truth.

## The core design question this answers
*"Won't the client keep those dividends/fees in a different account Citi never
sees?"* — Yes, often. So detection isn't one problem with one signal channel; it's
four sub-problems, each with a different real-world data source and different
coverage. Every client is assigned a **signal regime**:

| Regime | Real-world channel | Coverage in demo | Typical recall |
|---|---|---|---|
| `hub` | Citi is the client's cash-management hub even though investments sit elsewhere -> dividend sweeps / advisory-fee debits are organically visible | 30% | ~55-85% |
| `lending_disclosure` | Client disclosed their outside balance sheet for underwriting (mortgage / securities-based line of credit) | 15% | ~75-100% |
| `consented_aggregation` | Client opted into an account-linking / net-worth-dashboard feature | 15% | ~100% |
| `silo` | Fully external banking *and* investing — no organic Citi signal at all | 40% | **0%, by design** |

Every client, regardless of regime, also gets a **coarse, universal benchmark
signal** — modeled on real industry data consortiums such as **IXI Network
(Equifax)**, which directly measures roughly $20 trillion in anonymous U.S.
consumer assets and investments across 95+ member institutions, used explicitly for
household-level share-of-wallet estimation. It's deliberately weak (specificity
0.35, below the 0.50 decision threshold) — it can corroborate other evidence but
can never trigger a surfaced opportunity alone. This is what keeps `silo` clients
from being invisible *or* being guessed at: the system knows roughly that a
$21M-held-away client exists and says so, but correctly abstains rather than
acting on a coarse estimate. That's the honest answer to the "different account"
objection, made visible in the data rather than argued in a slide.

**Product implication worth stating on stage:** the fix isn't purely technical — it's
also a growth lever. The `consented_aggregation` regime is a UX opt-in (offer a
consolidated net-worth dashboard in exchange for linking outside accounts, the
same playbook Empower/eMoney use). Converting `silo` clients into that regime over
time is a natural roadmap slide with a number behind it: today X% of the book is
high-confidence; the aggregation flow grows that share.

## Quickstart
```bash
python gravity_datagen.py --n 50 --seed 7 --outdir ./out
```
Requires `numpy` and `pandas`.

## What it does
1. Samples **SCF-calibrated** client profiles (segment, wealth, composition, Citi wallet share).
2. Assigns each client a **signal regime** (see above) and an independent
   `prior_citi_relationship` flag (assets once at Citi that were transferred out —
   Citi is sender-of-record for ACATS/wires regardless of regime).
3. Builds a light **household / relationship graph** (spouse / trust / business, incl. cross-border).
4. Generates ~12 months of transactions and **plants held-away signals** per the
   client's regime, plus the universal weak benchmark — with deliberate false
   positives and false negatives so KPIs are non-trivial.
5. Runs a transparent **baseline inference** (specificity-weighted noisy-OR) as a
   stand-in for the real Gravity model.
6. **Scores** predictions vs ground truth overall *and broken out by signal regime*.

## Outputs (`./out/`)
| File | Contents |
|---|---|
| `clients.csv` | Labeled client book incl. `held_away_true` (ground truth), `signal_regime`, `prior_citi_relationship`, factors, household |
| `transactions.csv` | ~12 months of transactions per client; `is_signal` flags planted evidence |
| `signals.csv` | Extracted evidence rows: type, **specificity**, implied size, detail |
| `households.csv` | Relationship graph incl. regime and prior-relationship flags |
| `opportunity_book.csv` | Ranked opportunities: probability, size band, decision, evidence, **reason**, `expected_net_flow` |
| `kpi_report.json` | Precision / recall / F1 / FPR, abstention, size MAPE, calibration, **`by_signal_regime` breakdown** |

## Signal model (specificity = P(held-away | signal))
```
aggregation_linked_account        0.99   (client-consented account link)
external_statement_uploaded       0.98
credit_application_disclosure     0.97   (self-disclosed for underwriting)
recurring_advisory_fee_external   0.95   (hub regime only)
dividend_from_external_custodian  0.90   (hub regime; also enables size inference)
external_1099_tax_lots            0.88
wire_to_brokerage                 0.60   (requires prior_citi_relationship)
acats_transfer_out                0.55   (requires prior_citi_relationship)
ambiguous_large_outflow           0.30   (house / PE / consumption — deliberately weak)
external_wealth_benchmark         0.35   (universal, coarse, IXI-style — corroborator only)
```
Confidence combines via noisy-OR: `P = 1 - Prod(1 - specificity_i)`. Size prefers
statement-tier evidence (near ground truth) over dividend/transfer-implied sizing
over the noisy benchmark as a last resort. The baseline **abstains** when
confidence is low OR the estimated size is below the materiality gate.

## Tunable knobs (CONFIG or CLI)
- `--n`, `--seed`
- `--leakage` — probability the `hub` regime's organic transaction signal is visible in-window
- `--false-signal-rate` — misleading outflows on non-material clients (=> false positives)
- `regime_weights`, `prior_citi_relationship_rate`, `benchmark_noise`
- `size_noise`, `materiality_usd`, `surface_size_gate`, `decision_threshold`, `assumed_market_yield`

## Sample KPIs (n=50, seed=7)
```
overall:  precision 1.00 | recall 0.36 | FPR 0.00 | size MAPE 0.13
by regime:
  consented_aggregation  n=6   recall=1.00  precision=1.00
  lending_disclosure     n=5   recall=0.75  precision=1.00
  hub                    n=14  recall=0.57  precision=1.00
  silo                   n=25  recall=0.00  precision=None   <- correctly abstains
```
Across seeds 1-10, overall precision holds **0.87-1.00** with real, non-zero false
positives in most seeds, and overall recall lands **0.35-0.67** — capped almost
entirely by the `silo` share of the book. **Report recall by regime, not blended**,
in the pitch: the blended number understates what the system does well and
overstates what it can't see; the regime breakdown is the actually defensible story.

## Honest limitations (say these out loud in the deck)
- Distributions are **SCF-*calibrated*, not raw SCF microdata**. Swap `SEGMENTS` /
  `COMPOSITION` with real SCF percentiles (federalreserve.gov/econres/scfindex.htm)
  for production-grade calibration — the code path is unchanged.
- The regime mix (`regime_weights`) is a reasonable assumption, not a measured
  Citi statistic — replace with real adoption/disclosure rates if available.
- `baseline_infer` is a **stand-in**. Replace it with the real Gravity multi-model
  pipeline; the ground-truth labels and `score_kpis` are model-agnostic and stay put.
- The IXI-style benchmark is modeled generically; a real deployment would need an
  actual data licensing/compliance review before use (FCRA scope, permissible use).
- All data is synthetic — **no real client PII** (the correct posture for the demo).

## Productionization path
1. Replace `sample_clients` distributions with real SCF percentile tables and real
   regime-mix statistics (share of book that's hub / disclosed / aggregated / silo).
2. Point ingestion at Citi's real signals per regime: cash-management transaction
   feed (hub), lending/underwriting net-worth disclosures (lending_disclosure),
   an aggregation/account-linking product (consented_aggregation), and a licensed
   consortium benchmark (silo prior).
3. Swap `baseline_infer` for the Gravity pipeline; keep `score_kpis` — including
   the by-regime breakdown — to benchmark it against this labeled book.
4. Build the "invite to aggregate" conversion flow as a first-class Gravity
   feature: it's the roadmap for shrinking the `silo` segment over time.
