"""
Gravity - Synthetic Wealth Data Generator
==========================================

Purpose
-------
Produces a *labeled* synthetic book of wealth-management clients for the "Gravity"
held-away / share-of-wallet concept. It:

  1. Samples SCF-CALIBRATED client profiles (wealth, composition, segment, wallet share).
  2. Builds a light household / relationship graph.
  3. Generates ~12 months of transactions per client and PLANTS held-away *signals*
     at tunable confidence/leakage levels (with deliberate false positives and
     false negatives so KPIs are non-trivial).
  4. Runs a transparent BASELINE inference (specificity-weighted noisy-OR) as a
     stand-in for the real Gravity model, so the whole KPI harness is exercised.
  5. SCORES predictions vs ground truth: precision / recall / F1 / false-positive
     rate, abstention behaviour, size-estimate error, and probability calibration.

Honest calibration note
-----------------------
The distributions below are *inspired by* the Federal Reserve Survey of Consumer
Finances (SCF) shape (wealthy-oversampled, wealth composed across asset types) but
are hand-set parameters, NOT the raw SCF microdata (which lives at
federalreserve.gov/econres/scfindex.htm and isn't fetched here). Swap SEGMENTS and
COMPOSITION with real SCF percentiles for a production-grade calibration; the code
path is unchanged.

The BASELINE inferer is a stand-in ONLY. Replace `baseline_infer` with the real
Gravity multi-model pipeline; the ground-truth labels and scorer stay identical.

Run
---
    python gravity_datagen.py --n 50 --seed 7 --outdir ./out

Everything is seeded and tunable via CONFIG / CLI.
"""

import argparse
import json
import math
import os
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------- #
# CONFIG - everything a user would want to tune lives here
# --------------------------------------------------------------------------- #
CONFIG = {
    "n_clients": 50,
    "seed": 7,
    "months": 12,
    # Fraction of a client's TRUE held-away wealth that "leaks" into detectable
    # signals. Lower => more false negatives (held-away exists but we can't see it).
    "signal_leakage": 0.75,
    # Probability a NON-material client emits a misleading outflow
    # (e.g. bought a house / PE capital call / money moved out then back).
    "false_signal_rate": 0.20,
    # Multiplicative noise on the implied size estimate (0.20 = ~+/-20%).
    "size_noise": 0.20,
    # A client is a genuine opportunity only if true held-away >= this ($).
    "materiality_usd": 100_000,
    # Baseline won't surface unless the ESTIMATED size clears this gate (respects
    # materiality; lets small-external-tail clients be correctly ignored).
    "surface_size_gate": 100_000,
    # Predict "opportunity" when combined confidence >= this; below => ABSTAIN.
    "decision_threshold": 0.50,
    # Share of clients who are already fully consolidated at Citi (no opportunity).
    "already_consolidated_rate": 0.15,
    # Share of clients placed into shared households (spouse / trust / business).
    "household_rate": 0.20,
    "assumed_market_yield": 0.018,  # yield the inferer ASSUMES (adds realistic error)
    # --- Signal REGIME mix -----------------------------------------------
    # A client's held-away wealth is only detectable through channels Citi
    # actually has. Not every client generates every kind of signal:
    #   hub                  - Citi is the primary cash-mgmt/banking relationship
    #                           even though investments sit elsewhere -> dividend/
    #                           advisory-fee sweeps are organically visible.
    #   lending_disclosure    - client applied for Citi credit (mortgage / SBLOC)
    #                           and DISCLOSED their outside balance sheet for
    #                           underwriting -> near-ground-truth, size known.
    #   consented_aggregation - client opted into an account-linking / net-worth
    #                           dashboard feature -> near-ground-truth, size known.
    #   silo                  - fully external banking AND investing; Citi has NO
    #                           organic signal beyond a coarse, licensed, industry
    #                           consortium benchmark (IXI-Network-style estimate).
    "regime_weights": {"hub": 0.30, "lending_disclosure": 0.15,
                        "consented_aggregation": 0.15, "silo": 0.40},
    # Probability a client, independent of regime, once held assets AT Citi that
    # were later transferred out (Citi is sender-of-record for these ACATS/wires).
    "prior_citi_relationship_rate": 0.25,
    # Noise (relative) on the coarse, always-on consortium wealth-benchmark signal.
    "benchmark_noise": 0.65,
}

# SCF-calibrated segment parameters. Wealth is lognormal in log-USD space.
# wallet_share_beta = (a, b): Beta params for Citi's share of total investable wealth.
SEGMENTS = {
    "Citigold":               {"weight": 0.45, "log_mean": math.log(700_000),   "log_sd": 0.55, "wallet_share_beta": (2.0, 6.0)},
    "Citigold Private Client": {"weight": 0.25, "log_mean": math.log(2_500_000), "log_sd": 0.50, "wallet_share_beta": (2.0, 5.0)},
    "Citi Private Bank":       {"weight": 0.15, "log_mean": math.log(30_000_000),"log_sd": 0.70, "wallet_share_beta": (1.5, 7.0)},
    "Wealth at Work":          {"weight": 0.15, "log_mean": math.log(550_000),   "log_sd": 0.65, "wallet_share_beta": (2.0, 4.0)},
}

# SCF-shaped external portfolio composition (rough share by asset type).
COMPOSITION = {
    "public_equity": 0.34,
    "mutual_funds_etf": 0.24,
    "retirement": 0.18,
    "fixed_income": 0.10,
    "cash": 0.06,
    "alternatives": 0.05,
    "concentrated_stock": 0.03,
}

EXTERNAL_CUSTODIANS = [
    "Fidelity", "Vanguard", "Charles Schwab", "Morgan Stanley",
    "J.P. Morgan", "Merrill Lynch", "UBS",
]

JURISDICTIONS = ["US-NAM", "EMEA-UK", "APAC-SG", "LATAM-MX", "APAC-IN"]

LIFE_EVENTS = ["none", "none", "none", "business_sale", "inheritance",
               "retirement", "relocation_cross_border"]

# Signal specificity = P(held-away | this signal). Higher => stronger evidence.
SIGNAL_SPECIFICITY = {
    "external_statement_uploaded":      0.98,
    "aggregation_linked_account":       0.99,  # client-consented account link
    "credit_application_disclosure":    0.97,  # self-disclosed for underwriting
    "recurring_advisory_fee_external":  0.95,
    "dividend_from_external_custodian": 0.90,
    "external_1099_tax_lots":           0.88,
    "wire_to_brokerage":                0.60,
    "acats_transfer_out":               0.55,
    "ambiguous_large_outflow":          0.30,  # house / PE / consumption -> weak
    "external_wealth_benchmark":        0.35,  # coarse consortium estimate (e.g.
                                                # IXI-Network-style) - universal but
                                                # deliberately BELOW decision threshold
                                                # alone; corroborator, not sole trigger.
}
# Signals that let us BACK INTO a size estimate.
SIZING_SIGNALS = {"dividend_from_external_custodian", "acats_transfer_out",
                   "wire_to_brokerage", "external_wealth_benchmark"}
# Near-ground-truth signals (client stated or linked the number directly).
STATEMENT_SIGNALS = {"external_statement_uploaded", "external_1099_tax_lots",
                      "aggregation_linked_account", "credit_application_disclosure"}


# --------------------------------------------------------------------------- #
# 1. CLIENT PROFILES
# --------------------------------------------------------------------------- #
def sample_clients(cfg, rng):
    names = list(SEGMENTS.keys())
    weights = np.array([SEGMENTS[s]["weight"] for s in names])
    weights = weights / weights.sum()

    rows = []
    for i in range(cfg["n_clients"]):
        seg_name = rng.choice(names, p=weights)
        seg = SEGMENTS[seg_name]

        total_wealth = float(np.exp(rng.normal(seg["log_mean"], seg["log_sd"])))

        # Wallet share: mostly low (the core thesis), with a few fully-consolidated
        # clients (true negatives) and a few small-external-tail clients that sit
        # BELOW materiality. Those sub-material clients are what make the KPIs
        # honest: they create the false-positive / "don't chase small fry" tests.
        roll = rng.random()
        if roll < 0.10:                      # essentially fully consolidated at Citi
            held_away_true = float(rng.uniform(0, 15_000))
            citi_aum = max(0.0, total_wealth - held_away_true)
        elif roll < 0.28:                    # small external tail (sub-material)
            held_away_true = float(rng.uniform(20_000, 95_000))
            citi_aum = max(0.0, total_wealth - held_away_true)
        else:                                # the typical low-wallet-share client
            a, b = seg["wallet_share_beta"]
            citi_aum = total_wealth * float(rng.beta(a, b))
            held_away_true = max(0.0, total_wealth - citi_aum)
        wallet_share = citi_aum / total_wealth if total_wealth else 1.0

        # Blended dividend yield of the external book (drives external dividends).
        blended_yield = float(np.clip(rng.normal(0.020, 0.006), 0.005, 0.045))

        # Which real-world channel(s), if any, let Citi see this client's external
        # wealth. See CONFIG note above - this is the fix for "clients keep dividends
        # / fees in a DIFFERENT external account Citi never touches."
        regimes = list(cfg["regime_weights"].keys())
        rweights = np.array([cfg["regime_weights"][r] for r in regimes])
        signal_regime = rng.choice(regimes, p=rweights / rweights.sum())
        prior_citi_relationship = bool(rng.random() < cfg["prior_citi_relationship_rate"])

        rows.append({
            "client_id": f"C{i+1:04d}",
            "segment": seg_name,
            "jurisdiction": rng.choice(JURISDICTIONS, p=[0.45, 0.15, 0.15, 0.10, 0.15]),
            "age": int(np.clip(rng.normal(58, 12), 26, 92)),
            "tenure_years": int(np.clip(rng.normal(9, 6), 0, 35)),
            "total_investable_wealth": round(total_wealth, 2),
            "citi_aum": round(citi_aum, 2),
            "citi_wallet_share": round(wallet_share, 4),
            "held_away_true": round(held_away_true, 2),          # <-- GROUND TRUTH ($)
            "external_blended_yield": round(blended_yield, 4),
            "signal_regime": signal_regime,                       # <-- NEW
            "prior_citi_relationship": prior_citi_relationship,   # <-- NEW
            "life_event": rng.choice(LIFE_EVENTS),
            # Prioritisation factors (inputs to the ranking engine).
            "relationship_strength": round(float(rng.beta(3, 2)), 3),
            "client_engagement": round(float(rng.beta(2, 2)), 3),
            "advisor_capacity": round(float(rng.beta(2, 3)), 3),
            "primary_external_custodian": rng.choice(EXTERNAL_CUSTODIANS),
        })
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# 2. HOUSEHOLD / RELATIONSHIP GRAPH
# --------------------------------------------------------------------------- #
def build_households(clients, cfg, rng):
    household_id = ["" for _ in range(len(clients))]
    household_role = ["individual" for _ in range(len(clients))]
    hh_counter = 0
    idxs = list(range(len(clients)))
    rng.shuffle(idxs)

    i = 0
    while i < len(idxs):
        if rng.random() < cfg["household_rate"] and i + 1 < len(idxs):
            hh_counter += 1
            hid = f"HH{hh_counter:03d}"
            members = idxs[i:i + int(rng.integers(2, 4))]
            roles = ["primary", "spouse", "trust", "business_entity"]
            for k, m in enumerate(members):
                household_id[m] = hid
                household_role[m] = roles[k] if k < len(roles) else "beneficiary"
            i += len(members)
        else:
            hh_counter += 1
            household_id[idxs[i]] = f"HH{hh_counter:03d}"
            i += 1

    clients = clients.copy()
    clients["household_id"] = household_id
    clients["household_role"] = household_role
    return clients


# --------------------------------------------------------------------------- #
# 3. TRANSACTIONS + PLANTED SIGNALS
# --------------------------------------------------------------------------- #
def generate_transactions_and_signals(clients, cfg, rng):
    tx_rows, sig_rows = [], []
    months = cfg["months"]

    for _, c in clients.iterrows():
        cid = c["client_id"]
        monthly_income = max(4_000.0, c["total_investable_wealth"] * 0.004 / 12 + rng.normal(9_000, 3_000))

        # --- ambient (non-signal) transactions ---
        for m in range(months):
            tx_rows.append(_tx(cid, m, "payroll_credit", monthly_income, "Employer ACH", False))
            for _ in range(int(rng.integers(3, 8))):
                tx_rows.append(_tx(cid, m, "card_spend", -abs(rng.normal(1_200, 900)),
                                   rng.choice(["Retail", "Travel", "Dining", "Utilities"]), False))
            # internal Citi wealth activity (on-book)
            if rng.random() < 0.4:
                tx_rows.append(_tx(cid, m, "citi_investment_activity",
                                   rng.normal(0, c["citi_aum"] * 0.01 + 1), "Citi Wealth", False))

        held = c["held_away_true"]
        material = held >= cfg["materiality_usd"]
        sub_material = cfg["materiality_usd"] > held >= 20_000
        regime = c["signal_regime"]

        # --- UNIVERSAL weak prior: coarse consortium wealth benchmark ------
        # Present for (almost) every client regardless of regime - this is the
        # answer for "silo" clients who generate zero organic signal: an
        # industry-licensed, household-level estimate (IXI-Network-style),
        # heavily noised and deliberately too weak to trigger a decision alone.
        if rng.random() < 0.92:
            noise = float(np.clip(rng.normal(1.0, cfg["benchmark_noise"]), 0.05, 3.0))
            bench_est = max(0.0, held * noise) if held > 0 else abs(rng.normal(30_000, 40_000))
            sig_rows.append(_sig(cid, "external_wealth_benchmark", bench_est,
                                 "Household-level estimate from licensed asset-data "
                                 "consortium (coarse; not account-specific)",
                                 implied_size=bench_est))

        if not material:
            # Sub-material or zero held-away: only the false-signal / benchmark
            # channels apply below. No regime-specific organic signal fires.
            if sub_material and regime == "hub" and rng.random() < 0.7:
                annual_div = held * c["external_blended_yield"] * float(
                    np.clip(rng.normal(1.0, cfg["size_noise"]), 0.5, 1.6))
                for q in range(4):
                    m = min(months - 1, q * 3 + 1)
                    tx_rows.append(_tx(cid, m, "ach_credit", annual_div / 4,
                                       f"Dividend/interest - {c['primary_external_custodian']}", True))
                sig_rows.append(_sig(cid, "dividend_from_external_custodian", annual_div,
                                     f"Small recurring dividend from {c['primary_external_custodian']}",
                                     implied_size=annual_div / cfg["assumed_market_yield"]))
            elif (rng.random() < cfg["false_signal_rate"]):
                if rng.random() < 0.5:
                    amt = abs(rng.normal(600_000, 300_000))
                    m = int(rng.integers(0, months))
                    tx_rows.append(_tx(cid, m, "wire_out", -amt, "External transfer (purpose unknown)", True))
                    sig_rows.append(_sig(cid, "ambiguous_large_outflow", amt,
                                         "Large outbound wire, no corroborating evidence"))
                elif c["prior_citi_relationship"]:
                    amt = abs(rng.normal(500_000, 200_000))
                    m = int(rng.integers(0, months))
                    tx_rows.append(_tx(cid, m, "transfer_out", -amt,
                                       f"wire_to_brokerage -> {c['primary_external_custodian']}", True))
                    sig_rows.append(_sig(cid, "wire_to_brokerage", amt,
                                         f"One-off brokerage wire to {c['primary_external_custodian']} "
                                         "(no recurring evidence)", implied_size=amt))
            continue  # done with this client - no further signals for non-material

        # --- MATERIAL client: signal depends entirely on regime -------------
        # NOTE: signal_leakage models whether an ORGANIC transaction signal
        # happens to be visible in a given window - it only makes sense for the
        # "hub" channel. Disclosure/aggregation are deterministic once that
        # regime applies (the file exists / the link is live), so they get
        # their own, much higher, independent activation probability instead
        # of being gated by the same "did a transaction leak" coin flip.
        visible = held * float(np.clip(rng.normal(0.7, 0.2), 0.2, 1.0))

        if regime == "hub" and rng.random() < cfg["signal_leakage"]:
            _plant_hub_signals(cid, c, visible, months, cfg, rng, tx_rows, sig_rows)
        elif regime == "lending_disclosure" and rng.random() < 0.90:
            sig_rows.append(_sig(cid, "credit_application_disclosure", held,
                                 "Outside net-worth statement on file from a Citi "
                                 "credit/lending application (mortgage / SBLOC underwriting)",
                                 implied_size=held * float(np.clip(rng.normal(1.0, 0.05), 0.9, 1.1))))
        elif regime == "consented_aggregation" and rng.random() < 0.92:
            sig_rows.append(_sig(cid, "aggregation_linked_account", held,
                                 "Client linked outside account via consented aggregation",
                                 implied_size=held * float(np.clip(rng.normal(1.0, 0.04), 0.92, 1.08))))
        # regime == "silo" (or the above roll missed): no organic signal beyond
        # the universal benchmark planted earlier -> this is a genuine, honest
        # false negative and is exactly what the regime KPI breakdown is meant
        # to surface, not hide.

        # ACATS-out / brokerage wire is a SEPARATE channel: possible whenever
        # assets were once at Citi and left, regardless of the client's regime.
        if c["prior_citi_relationship"] and rng.random() < 0.45:
            amt = visible * float(np.clip(rng.normal(0.4, 0.25), 0.05, 1.0))
            m = int(rng.integers(0, months))
            typ = "acats_transfer_out" if rng.random() < 0.6 else "wire_to_brokerage"
            tx_rows.append(_tx(cid, m, "transfer_out", -amt,
                               f"{typ} -> {c['primary_external_custodian']}", True))
            sig_rows.append(_sig(cid, typ, amt,
                                 f"{typ.replace('_',' ')} to {c['primary_external_custodian']} "
                                 "(assets previously held at Citi)", implied_size=amt))

    return pd.DataFrame(tx_rows), pd.DataFrame(sig_rows)


def _plant_hub_signals(cid, c, visible, months, cfg, rng, tx_rows, sig_rows):
    """Hub-regime clients: Citi is the cash-management hub, so dividend sweeps
    and advisory-fee debits from the EXTERNAL manager organically flow through
    a Citi account. This is the one regime where the old 'wait for the ACH'
    logic is realistic - it does NOT generalize to every client."""
    yld = c["external_blended_yield"]
    cust = c["primary_external_custodian"]

    if rng.random() < 0.85:
        annual_div = visible * yld * float(np.clip(rng.normal(1.0, cfg["size_noise"]), 0.4, 1.8))
        for q in range(4):
            m = min(months - 1, q * 3 + 1)
            tx_rows.append(_tx(cid, m, "ach_credit", annual_div / 4,
                               f"Dividend/interest - {cust}", True))
        sig_rows.append(_sig(cid, "dividend_from_external_custodian", annual_div,
                             f"Recurring dividend/interest ACH from {cust} sweeping "
                             "into Citi cash-management account",
                             implied_size=annual_div / cfg["assumed_market_yield"]))

    if rng.random() < 0.55:
        fee = visible * float(np.clip(rng.normal(0.009, 0.003), 0.003, 0.02))
        for m in range(0, months, 3):
            tx_rows.append(_tx(cid, m, "ach_debit", -fee / 4, f"Advisory fee - {cust}", True))
        sig_rows.append(_sig(cid, "recurring_advisory_fee_external", fee,
                             f"Quarterly advisory-fee debit to {cust} (externally "
                             "advised, but fee auto-pays from Citi account)"))


def _tx(cid, month, kind, amount, desc, is_signal):
    return {"client_id": cid, "month": int(month), "kind": kind,
            "amount": round(float(amount), 2), "description": desc,
            "is_signal": bool(is_signal)}


def _sig(cid, sig_type, raw_amount, detail, implied_size=None):
    return {"client_id": cid, "signal_type": sig_type,
            "specificity": SIGNAL_SPECIFICITY[sig_type],
            "raw_amount": round(float(raw_amount), 2),
            "implied_size": None if implied_size is None else round(float(implied_size), 2),
            "detail": detail}


# --------------------------------------------------------------------------- #
# 4. BASELINE INFERENCE  (stand-in for the real Gravity model)
# --------------------------------------------------------------------------- #
def baseline_infer(clients, signals, cfg):
    """Transparent specificity-weighted noisy-OR. Returns a probability, a size
    band, and the evidence list per client. Abstains when confidence is low."""
    out = []
    grouped = signals.groupby("client_id") if len(signals) else {}
    sig_by_client = {cid: df for cid, df in grouped} if len(signals) else {}

    for _, c in clients.iterrows():
        cid = c["client_id"]
        sdf = sig_by_client.get(cid)

        if sdf is None or len(sdf) == 0:
            out.append({"client_id": cid, "pred_probability": 0.0,
                        "pred_size_low": 0.0, "pred_size_mid": 0.0, "pred_size_high": 0.0,
                        "decision": "abstain", "n_signals": 0, "evidence": "none",
                        "reason": "no external signal detected"})
            continue

        # noisy-OR combine: P = 1 - prod(1 - specificity_i)
        prob = 1.0 - float(np.prod([1.0 - s for s in sdf["specificity"]]))

        sized = sdf[sdf["signal_type"].isin(SIZING_SIGNALS - {"external_wealth_benchmark"})
                    & sdf["implied_size"].notna()]
        benchmark = sdf[(sdf["signal_type"] == "external_wealth_benchmark")
                         & sdf["implied_size"].notna()]
        statement = sdf[sdf["signal_type"].isin(STATEMENT_SIGNALS) & sdf["implied_size"].notna()]

        if len(statement):                       # ground-truth-ish evidence wins
            size_mid = float(statement["implied_size"].mean())
        elif len(sized):                         # dividend / transfer evidence next
            size_mid = float(sized["implied_size"].mean())
        elif len(benchmark):                     # coarse benchmark = last resort
            size_mid = float(benchmark["implied_size"].mean())
        else:
            size_mid = 0.0

        band = cfg["size_noise"] if (len(statement) or len(sized)) else cfg["benchmark_noise"]
        if prob >= cfg["decision_threshold"] and size_mid >= cfg["surface_size_gate"]:
            decision = "surface"
            reason = f"{len(sdf)} signals; confidence {prob:.0%}; est ${size_mid:,.0f}"
        elif prob < cfg["decision_threshold"]:
            decision, reason = "abstain", f"signals too weak (confidence {prob:.0%})"
        else:
            decision, reason = "abstain", f"est ${size_mid:,.0f} below materiality gate"

        out.append({
            "client_id": cid,
            "pred_probability": round(prob, 4),
            "pred_size_low": round(size_mid * (1 - band), 2),
            "pred_size_mid": round(size_mid, 2),
            "pred_size_high": round(size_mid * (1 + band), 2),
            "decision": decision,
            "n_signals": int(len(sdf)),
            "evidence": "; ".join(sorted(set(sdf["signal_type"]))),
            "reason": reason,
        })
    return pd.DataFrame(out)


# --------------------------------------------------------------------------- #
# 5. OPPORTUNITY RANKING  (weighted, NOT naive product-to-zero)
# --------------------------------------------------------------------------- #
def rank_opportunities(clients, preds, cfg):
    df = clients.merge(preds, on="client_id")

    def life_mult(ev):
        return {"business_sale": 1.6, "inheritance": 1.4, "retirement": 1.2,
                "relocation_cross_border": 1.25, "none": 1.0}.get(ev, 1.0)

    # Each soft factor scaled into [0.6, 1.4] so no single factor zeroes the score.
    def scale(x):
        return 0.6 + 0.8 * float(x)

    exp_net_flow = (
        df["pred_size_mid"] * df["pred_probability"]
        * df["relationship_strength"].map(scale)
        * df["client_engagement"].map(scale)
        * df["advisor_capacity"].map(scale)
        * df["life_event"].map(life_mult)
    )
    df["expected_net_flow"] = exp_net_flow.round(2)

    # Two DISTINCT views, deliberately not blended: an advisor should never see a
    # ranked "opportunity" that the system actually abstained on mixed in with
    # ones it's confident enough to act on.
    surfaced = df["decision"] == "surface"
    df["rank"] = pd.Series(dtype="float64")
    df.loc[surfaced, "rank"] = (
        df.loc[surfaced, "expected_net_flow"].rank(ascending=False, method="first"))
    df["watchlist_rank"] = pd.Series(dtype="float64")
    df.loc[~surfaced, "watchlist_rank"] = (
        df.loc[~surfaced, "pred_size_mid"].rank(ascending=False, method="first"))

    return df.sort_values(["decision", "rank"], ascending=[False, True])


# --------------------------------------------------------------------------- #
# 6. KPI SCORING  (vs ground truth)
# --------------------------------------------------------------------------- #
def score_kpis(ranked, cfg):
    mat = cfg["materiality_usd"]
    y_true = ranked["held_away_true"] >= mat
    y_pred = ranked["decision"] == "surface"

    tp = int((y_true & y_pred).sum())
    fp = int((~y_true & y_pred).sum())
    fn = int((y_true & ~y_pred).sum())
    tn = int((~y_true & ~y_pred).sum())

    precision = tp / (tp + fp) if (tp + fp) else None
    recall = tp / (tp + fn) if (tp + fn) else None
    f1 = (2 * precision * recall / (precision + recall)
          if precision and recall else None)
    fpr = fp / (fp + tn) if (fp + tn) else None

    # size-estimate error on true positives that we surfaced
    tp_rows = ranked[y_true & y_pred]
    if len(tp_rows):
        ape = (abs(tp_rows["pred_size_mid"] - tp_rows["held_away_true"])
               / tp_rows["held_away_true"])
        size_mape = float(ape.mean())
    else:
        size_mape = None

    # calibration: predicted-prob buckets vs actual positive rate
    calibration = []
    surf = ranked[ranked["decision"] == "surface"]
    if len(surf):
        buckets = [(0.5, 0.7), (0.7, 0.9), (0.9, 1.01)]
        for lo, hi in buckets:
            b = surf[(surf["pred_probability"] >= lo) & (surf["pred_probability"] < hi)]
            if len(b):
                calibration.append({
                    "prob_bucket": f"{lo:.2f}-{hi:.2f}",
                    "n": int(len(b)),
                    "mean_pred_prob": round(float(b["pred_probability"].mean()), 3),
                    "actual_positive_rate": round(float((b["held_away_true"] >= mat).mean()), 3),
                })

    # --- Breakdown by signal REGIME: this is the honest answer to "won't the
    # client keep the dividends/fees in a different account?" -> recall should
    # be near-complete where the regime supports it, and low (correctly
    # abstaining) where it doesn't.
    by_regime = []
    for regime, g in ranked.groupby("signal_regime"):
        yt = g["held_away_true"] >= mat
        yp = g["decision"] == "surface"
        rtp, rfp = int((yt & yp).sum()), int((~yt & yp).sum())
        rfn, rtn = int((yt & ~yp).sum()), int((~yt & ~yp).sum())
        by_regime.append({
            "signal_regime": regime,
            "n_clients": int(len(g)),
            "n_true_opportunities": int(yt.sum()),
            "surfaced": int(yp.sum()),
            "recall": _r(rtp / (rtp + rfn)) if (rtp + rfn) else None,
            "precision": _r(rtp / (rtp + rfp)) if (rtp + rfp) else None,
        })

    return {
        "n_clients": int(len(ranked)),
        "n_true_opportunities": int(y_true.sum()),
        "confusion": {"tp": tp, "fp": fp, "fn": fn, "tn": tn},
        "precision": _r(precision), "recall": _r(recall), "f1": _r(f1),
        "false_positive_rate": _r(fpr),
        "abstained": int((ranked["decision"] == "abstain").sum()),
        "abstained_correctly": int(((ranked["decision"] == "abstain") & ~y_true).sum()),
        "size_estimate_MAPE": _r(size_mape),
        "calibration": calibration,
        "by_signal_regime": by_regime,
        "config": cfg,
    }


def _r(x, nd=3):
    return None if x is None else round(float(x), nd)


# --------------------------------------------------------------------------- #
# MAIN
# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description="Gravity synthetic data generator")
    ap.add_argument("--n", type=int, default=CONFIG["n_clients"])
    ap.add_argument("--seed", type=int, default=CONFIG["seed"])
    ap.add_argument("--outdir", type=str, default="./out")
    ap.add_argument("--leakage", type=float, default=CONFIG["signal_leakage"])
    ap.add_argument("--false-signal-rate", type=float, default=CONFIG["false_signal_rate"])
    args = ap.parse_args()

    cfg = dict(CONFIG)
    cfg.update(n_clients=args.n, seed=args.seed,
               signal_leakage=args.leakage, false_signal_rate=args.false_signal_rate)

    rng = np.random.default_rng(cfg["seed"])
    os.makedirs(args.outdir, exist_ok=True)

    clients = sample_clients(cfg, rng)
    clients = build_households(clients, cfg, rng)
    transactions, signals = generate_transactions_and_signals(clients, cfg, rng)
    preds = baseline_infer(clients, signals, cfg)
    ranked = rank_opportunities(clients, preds, cfg)
    kpis = score_kpis(ranked, cfg)

    # Write outputs
    clients.to_csv(os.path.join(args.outdir, "clients.csv"), index=False)
    transactions.to_csv(os.path.join(args.outdir, "transactions.csv"), index=False)
    signals.to_csv(os.path.join(args.outdir, "signals.csv"), index=False)
    households = (clients[["household_id", "client_id", "household_role", "segment",
                          "jurisdiction", "signal_regime", "prior_citi_relationship"]]
                  .sort_values(["household_id", "household_role"]))
    households.to_csv(os.path.join(args.outdir, "households.csv"), index=False)
    ranked.to_csv(os.path.join(args.outdir, "opportunity_book.csv"), index=False)
    with open(os.path.join(args.outdir, "kpi_report.json"), "w") as f:
        json.dump(kpis, f, indent=2)

    # Console summary
    print(f"Generated {len(clients)} clients, {len(transactions)} transactions, "
          f"{len(signals)} signals.")
    print(f"True opportunities (held-away >= ${cfg['materiality_usd']:,}): "
          f"{kpis['n_true_opportunities']}")
    print(f"Confusion: {kpis['confusion']}")
    print(f"Precision={kpis['precision']}  Recall={kpis['recall']}  "
          f"F1={kpis['f1']}  FPR={kpis['false_positive_rate']}")
    print(f"Abstained={kpis['abstained']} (correctly={kpis['abstained_correctly']})  "
          f"Size MAPE={kpis['size_estimate_MAPE']}")
    print("\nRecall / precision by signal regime (the answer to 'different external account'):")
    for r in kpis["by_signal_regime"]:
        print(f"  {r['signal_regime']:<22} n={r['n_clients']:<3} "
              f"true_opps={r['n_true_opportunities']:<3} surfaced={r['surfaced']:<3} "
              f"recall={r['recall']}  precision={r['precision']}")
    print("\nTop 5 ACTIONABLE opportunities (surfaced - advisor should act):")
    cols = ["rank", "client_id", "segment", "signal_regime", "held_away_true",
            "pred_size_mid", "pred_probability", "expected_net_flow", "life_event"]
    top_action = ranked[ranked["decision"] == "surface"].sort_values("rank").head(5)
    print(top_action[cols].to_string(index=False) if len(top_action) else "  (none surfaced)")

    print("\nTop 5 WATCHLIST (high estimated value, but abstained - not shown to advisor "
          "as an action; candidates for the aggregation-invite flow):")
    wcols = ["watchlist_rank", "client_id", "segment", "signal_regime",
             "held_away_true", "pred_probability", "reason"]
    top_watch = ranked[ranked["decision"] == "abstain"].sort_values("watchlist_rank").head(5)
    print(top_watch[wcols].to_string(index=False) if len(top_watch) else "  (none)")


if __name__ == "__main__":
    main()
